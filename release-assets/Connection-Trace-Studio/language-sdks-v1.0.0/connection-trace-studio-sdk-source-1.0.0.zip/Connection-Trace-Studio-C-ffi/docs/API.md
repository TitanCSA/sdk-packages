# Connection-Trace-Studio operation schema

The unchanged product C++ SDK is called directly. Operations: `check`, `start`, `stop`, `status`, `read`, `format_event`, `correlate`. The dispatch source in `Bridge.cpp` lists exact argument keys and maps every operation to the original public SDK. Protocol structs retain their public-header field names, including case. UInt64 and Int64 fields are decimal strings; fixed arrays accept at most their capacity and omitted fields initialize to zero. Unknown fields and out-of-range values are rejected. SDK validators apply original protocol constraints.

Wire types and fields:

- `CT_REQUEST`: Magic, Version, Size, Options
- `CT_EVENT`: Sequence, TimestampQpc, ProcessId, EndpointId, Flags, LocalPort, RemotePort, Family, Stage, Protocol, Reserved, LocalAddress, RemoteAddress, PathLength, Reserved2, Application
- `CT_STATUS`: Magic, Version, Size, Active, QpcFrequency, Produced, Dropped, Available, Capacity, Options, Reserved
- `CT_BATCH`: Magic, Version, Size, Count, Dropped, Events

Only explicit start/connect/policy calls start the corresponding operation. The C ABI session constructor is inert; one active session per product DLL. Always close. Capture receives are bounded when the native API accepts a timeout. SDK original licensing/trial checks remain unchanged. No driver is installed by packages.

Tests exercise synthetic wire inputs using the real production SDK validation/formatting helpers, rejected arguments, exact unsigned values and inert session lifecycle. No live capture, policy application, storage fault, traffic modification or driver activation is performed by these tests. Operational driver paths require a separate integration environment.
