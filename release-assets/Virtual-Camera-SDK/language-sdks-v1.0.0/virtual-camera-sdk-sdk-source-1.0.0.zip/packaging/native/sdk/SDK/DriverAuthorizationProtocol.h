#ifndef TITAN_DRIVER_AUTHORIZATION_PROTOCOL_H
#define TITAN_DRIVER_AUTHORIZATION_PROTOCOL_H
#pragma once
#ifdef _KERNEL_MODE
#include <ntddk.h>
typedef ULONG TITAN_AUTH_U32;
typedef UCHAR TITAN_AUTH_U8;
#else
#include <stdint.h>
typedef uint32_t TITAN_AUTH_U32;
typedef uint8_t TITAN_AUTH_U8;
#endif

#define TITAN_AUTHORIZATION_MAGIC 0x314C5654u
#define TITAN_AUTHORIZATION_VERSION 1u
#define TITAN_AUTHORIZATION_NETWORK 1u
#define TITAN_AUTHORIZATION_CAMERA 2u
#define TITAN_AUTHORIZATION_MAX_SECONDS 3600u

typedef struct TITAN_AUTHORIZATION_CHALLENGE {
    TITAN_AUTH_U32 magic;
    TITAN_AUTH_U32 version;
    TITAN_AUTH_U32 product;
    TITAN_AUTH_U32 duration_seconds; /* zero in challenges */
    TITAN_AUTH_U8 nonce[32];
} TITAN_AUTHORIZATION_CHALLENGE;

typedef struct TITAN_AUTHORIZATION_TOKEN {
    TITAN_AUTHORIZATION_CHALLENGE permission;
    TITAN_AUTH_U8 signature[64]; /* ECDSA P-256/SHA-256, big-endian R || S */
} TITAN_AUTHORIZATION_TOKEN;

#ifdef __cplusplus
static_assert(sizeof(TITAN_AUTHORIZATION_CHALLENGE) == 48);
static_assert(sizeof(TITAN_AUTHORIZATION_TOKEN) == 112);
#else
C_ASSERT(sizeof(TITAN_AUTHORIZATION_CHALLENGE) == 48);
C_ASSERT(sizeof(TITAN_AUTHORIZATION_TOKEN) == 112);
#endif

#endif // TITAN_DRIVER_AUTHORIZATION_PROTOCOL_H
