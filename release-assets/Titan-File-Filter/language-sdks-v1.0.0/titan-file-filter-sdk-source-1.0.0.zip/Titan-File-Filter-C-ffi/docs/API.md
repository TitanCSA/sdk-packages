# Titan-File-Filter operation schema

The unchanged product C++ SDK is called directly. Operations: `check`, `make_rule`, `start`, `set_rules`, `stop`, `status`, `read`, `event_path`, `operation_names`. The dispatch source in `Bridge.cpp` lists exact argument keys and maps every operation to the original public SDK. Protocol structs retain their public-header field names, including case. UInt64 and Int64 fields are decimal strings; fixed arrays accept at most their capacity and omitted fields initialize to zero. Unknown fields and out-of-range values are rejected. SDK validators apply original protocol constraints.

Wire types and fields:

- `FF_RULE`: Id, ProcessId, Operations, Action, PathLength, Reserved, Folder
- `FF_COMMAND`: Magic, Version, Size, Operation, Count, Reserved
- `FF_POLICY`: Header, Rules
- `FF_EVENT`: Sequence, Generation, StartQpc, DurationQpc, RequestedBytes, TransferredBytes, ProcessId, RuleId, Operations, Status, Flags, PathLength, TargetLength, Path, Target
- `FF_STATUS`: Magic, Version, Size, Count, RuleCount, Inflight, Capacity, Reserved, Generation, Frequency, Observed, Denied, Dropped, NameFailures, Skipped, NextSequence
- `FF_REPLY`: Status, Events

Only explicit start/connect/policy calls start the corresponding operation. The C ABI session constructor is inert; one active session per product DLL. Always close. Capture receives are bounded when the native API accepts a timeout. SDK original licensing/trial checks remain unchanged. No driver is installed by packages.

Tests exercise synthetic wire inputs using the real production SDK validation/formatting helpers, rejected arguments, exact unsigned values and inert session lifecycle. No live capture, policy application, storage fault, traffic modification or driver activation is performed by these tests. Operational driver paths require a separate integration environment.
